<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hangout;

class HangoutController extends Controller
{
    public function index()
    {
        $hangouts = Hangout::all();

        return view('hangout.index', compact('hangouts'));
    }

    public function store(Request $request)
    {
        Hangout::create([
            'nama_tempat' => $request->nama_tempat,
            'lokasi' => $request->lokasi,
            'rating' => $request->rating,
            'suasana' => $request->suasana,
        ]);

        return redirect('/');
    }

    public function destroy($id)
    {
    $hangout = Hangout::findOrFail($id);
    $hangout->delete();

    return redirect('/');
    }

    public function update(Request $request, $id)
    {
    $hangout = Hangout::findOrFail($id);

    $hangout->update([
        'nama_tempat' => $request->nama_tempat,
        'lokasi' => $request->lokasi,
        'rating' => $request->rating,
        'suasana' => $request->suasana,
    ]);

    return redirect('/');
    }
}